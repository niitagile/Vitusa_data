package com.servicelocator.pattern;
public class InitialContext {
	
	public Object lookup(String jndiName){
		   
		if(jndiName.equalsIgnoreCase("OPERATION")){
			System.out.println("Looking up and creating a new OperationBusinessService object");
			return new OperationBusinessService();
		}else if (jndiName.equalsIgnoreCase("CLIENT")){
			System.out.println("Looking up and creating a new ClientBusinessService object");
			return new ClientBusinessService();
		}
		return null;			
	}
}