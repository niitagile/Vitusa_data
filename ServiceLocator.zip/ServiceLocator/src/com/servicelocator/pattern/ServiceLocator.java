package com.servicelocator.pattern;
public class ServiceLocator {
	
	private static ServicesCache servicesCache;

	   static {
		   servicesCache = new ServicesCache();		
	   }

	   public static BusinessService getBusinessService(String jndiName){

		   BusinessService businessService = servicesCache.getBusinessService(jndiName);

	      if(businessService != null){
	         return businessService;
	      }

	      InitialContext context = new InitialContext();
	      BusinessService businessService2 = (BusinessService)context.lookup(jndiName);
	      servicesCache.addBusinessService(businessService2);
	      return businessService2;
	   }
}
