package com.servicelocator.pattern;
public class OperationBusinessService implements BusinessService {

	@Override
	public String getServiceName() {
		return "Operation";
	}

	@Override
	public void executeService() {
		System.out.println("Executing Business Service for Operation Team");
	}

}
