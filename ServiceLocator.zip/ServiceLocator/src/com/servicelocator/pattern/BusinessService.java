package com.servicelocator.pattern;
public interface BusinessService {
	
	public String getServiceName();
	
	public void executeService();
}
