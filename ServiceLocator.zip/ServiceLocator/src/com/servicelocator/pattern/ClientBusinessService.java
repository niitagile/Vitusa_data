package com.servicelocator.pattern;
public class ClientBusinessService implements BusinessService {

	@Override
	public String getServiceName() {
		return "Client";
	}

	@Override
	public void executeService() {
		System.out.println("Executing Business Service for Client");
	}

}
