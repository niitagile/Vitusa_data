package com.servicelocator.pattern;
public class ServiceLocatorPatternDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BusinessService businessService = ServiceLocator.getBusinessService("OPERATION");
		businessService.executeService();
		businessService = ServiceLocator.getBusinessService("CLIENT");
		businessService.executeService();
		businessService = ServiceLocator.getBusinessService("OPERATION");
		businessService.executeService();
		businessService = ServiceLocator.getBusinessService("CLIENT");
		businessService.executeService();	
	}

}