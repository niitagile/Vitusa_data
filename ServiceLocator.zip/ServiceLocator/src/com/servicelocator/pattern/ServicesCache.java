package com.servicelocator.pattern;

import java.util.ArrayList;
import java.util.List;

public class ServicesCache {
	
	private List<BusinessService> businessServices;

	public ServicesCache(){
		businessServices = new ArrayList<>();
	}

	public BusinessService getBusinessService(String serviceName){
	   
		for (BusinessService businessService : businessServices) {
			if(businessService.getServiceName().equalsIgnoreCase(serviceName)){
				System.out.println("Returning cached  " + serviceName + " object");
				return businessService;
			}
		}
		return null;
	}

	public void addBusinessService(BusinessService newBusinessService){
		boolean exists = false;
	      
		for (BusinessService businessService : businessServices) {
			if(businessService.getServiceName().equalsIgnoreCase(newBusinessService.getServiceName())){
				exists = true;
	         }
		}
		if(!exists){
			businessServices.add(newBusinessService);
		}
	}
}
