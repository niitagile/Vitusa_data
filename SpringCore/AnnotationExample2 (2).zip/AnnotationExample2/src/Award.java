
public interface Award {
		void award();
}
