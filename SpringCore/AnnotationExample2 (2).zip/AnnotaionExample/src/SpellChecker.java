
public class SpellChecker {
	public SpellChecker(){
		System.out.println("Spellchecker Construtor");
	}
	public void checkSpelling(){
		System.out.println("checking is going on");
	}

}
