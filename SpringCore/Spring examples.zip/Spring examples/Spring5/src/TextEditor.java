
public class TextEditor {
	private SpellChecker sp;
	private String sname;
	

	public TextEditor() {
		super();
	}
	public TextEditor(SpellChecker sp) {
		super();
		this.sp = sp;
	}
	public void spellCheck(){
		sp.checkSpelling();
	}
	public void setSp(SpellChecker sp) {
		this.sp = sp;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	
	
}
