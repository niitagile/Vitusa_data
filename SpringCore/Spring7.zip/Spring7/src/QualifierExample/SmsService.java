package QualifierExample;

public class SmsService implements MessageService {

	@Override
	public void sendMsg(String message) {
		// TODO Auto-generated method stub
		System.out.println(message);
	}

}
