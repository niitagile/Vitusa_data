package QualifierExample;
import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.core.io.ClassPathResource;  
import org.springframework.core.io.Resource;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
  import org.springframework.beans.annotation.*;
public class Test {  
public static void main(String[] args) {  
   
	ApplicationContext context = new AnnotationConfigApplicationContext("ApplicationConfiguration.class");
	MessageProcessor obj = (MessageProcessor)context.getBean("MessageProcessor.class");
	obj.processMsg("twitter message is sending...");
	
	
	
}  
}  