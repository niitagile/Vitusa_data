package QualifierExample;

public interface MessageProcessor {
	public void processMsg(String message);

}
