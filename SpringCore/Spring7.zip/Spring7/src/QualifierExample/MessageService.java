package QualifierExample;

public interface MessageService {
	public void sendMsg(String message);

}
