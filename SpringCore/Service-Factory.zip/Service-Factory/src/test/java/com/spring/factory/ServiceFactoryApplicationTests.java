package com.spring.factory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceFactoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
