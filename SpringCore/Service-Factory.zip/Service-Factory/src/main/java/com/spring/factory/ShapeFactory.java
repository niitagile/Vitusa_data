package com.spring.factory;

import com.spring.factory.shape.Shape;

public interface ShapeFactory {
    
    Shape getShape(String name);
    
}