package com.spring.factory;
import com.spring.factory.shape.*;
public interface ShapeFactory {
	
	Shape getShape(String name);
	

}
