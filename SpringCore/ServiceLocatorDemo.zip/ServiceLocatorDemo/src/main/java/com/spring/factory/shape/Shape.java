package com.spring.factory.shape;

public interface Shape {
		void draw();
}
