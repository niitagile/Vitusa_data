package com.spring.factory.shape.impl;

import com.spring.factory.shape.Shape;

public class Circle implements Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("This is circle shape");
	}
	

}
