package com.rest.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestCrudExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestCrudExampleApplication.class, args);
	}

}
