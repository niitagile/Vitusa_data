package com.virtusa.beans;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Store {
	public static void main(String[] args) {
		
		//Add Readers
		Set<ReaderEntity> rlist=new HashSet<ReaderEntity>();
		ReaderEntity readerone=new ReaderEntity();
		readerone.setReaderName("Kanika");
			
		ReaderEntity readertwo=new ReaderEntity();
		readerone.setReaderName("Kanika");
		rlist.add(readerone);
		rlist.add(readertwo);
		
		
		
		Set<SubscriptionEntity> slist=new HashSet<SubscriptionEntity>();
	     SubscriptionEntity sone=new SubscriptionEntity();
	     sone.setSubsname("primevideo");
	     SubscriptionEntity stwo=new SubscriptionEntity();
	     sone.setSubsname("hotstar");
	     slist.add(sone);
	     slist.add(stwo);
	     
	     readerone.setSubscriptions(slist);
	     readertwo.setSubscriptions(slist);
	     
	    SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(readerone);
		session.save(readertwo);
		
		session.getTransaction().commit();
	}

}
