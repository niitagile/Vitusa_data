package com.virtusa.beans;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJdbc1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
