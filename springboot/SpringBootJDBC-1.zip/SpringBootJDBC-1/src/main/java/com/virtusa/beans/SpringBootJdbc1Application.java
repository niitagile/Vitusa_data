package com.virtusa.beans;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJdbc1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJdbc1Application.class, args);
	}

}
