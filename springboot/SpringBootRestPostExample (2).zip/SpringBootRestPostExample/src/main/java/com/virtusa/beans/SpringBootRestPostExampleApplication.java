package com.virtusa.beans;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestPostExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestPostExampleApplication.class, args);
	}

}
