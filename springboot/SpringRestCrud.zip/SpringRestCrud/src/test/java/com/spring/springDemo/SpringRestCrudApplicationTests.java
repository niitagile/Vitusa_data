package com.spring.springDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
