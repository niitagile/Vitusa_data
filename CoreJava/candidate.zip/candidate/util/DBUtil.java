package com.wipro.candidate.util;

import java.sql.Connection;
import java.sql.DriverManager;


public class DBUtil {
public static Connection getDBConn()
{
	Connection con=null;
	//write code here
	try{
		//Class.forName("oracle.jdbc.driver.OracleDriver");
		Class.forName("oracle.jdbc.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","B202002202002006","B202002202002006");
	}catch(Exception e){
		e.printStackTrace();
	}
	
	return con;
}
}
