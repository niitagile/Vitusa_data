package com.wipro.candidate.service;

import java.util.ArrayList;


import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.dao.CandidateDAO;
import com.wipro.candidate.util.WrongDataException;


public class CandidateMain {

	/**
	 * @param args
	 */
	public String addCandidate(CandidateBean studBean)
	{
		String result="";
		int m1,m2,m3;
		try{
		if(studBean==null)
			throw new WrongDataException();
		else{
			m1=studBean.getM1();
			 m2=studBean.getM2();
			 m3=studBean.getM3();
			
			if(studBean.getName().isEmpty()||studBean.getName().length()<2||
					(m1<0 || m1>100)||(m2<0 || m2>100)||(m2<0 || m2>100))
							
			throw new WrongDataException();				
							
				
		}
		CandidateDAO bean=new CandidateDAO();
		studBean.setId(bean.generateCandidateId(studBean.getName()));
		int sum=m1+m2+m3;
		String res="PASS",grade;
		if(sum>=240)
			grade="Distinct";
		else
			if(sum>=180)
				grade="First Class";
		else
			if(sum>=150)
				grade="Second Class";
		else
			if(sum>=105)
				grade="Third Class";
			else{
				res="FAIL";
				grade="No Grade";
			}
		studBean.setResult(res);
		studBean.setGrade(grade);
		String r=new CandidateDAO().addCandidate(studBean);
		//String r=candidate.addCandidate(studBean);
		if(r.equals("SUCCESS"))
			return studBean.getId()+":"+studBean.getResult();
		else
			result="FAIL";
			
		
		}catch(Exception e){
			result=e.toString();
		}
			
	    //write code here
	    return result;
		
	}
	public ArrayList<CandidateBean> displayAll(String criteria)
	{
		ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();
		try{
		criteria=criteria.toUpperCase();
		if(criteria.equals("PASS")||criteria.equals("FAIL")||criteria.equals("ALL"))
		list=new CandidateDAO().getByResult(criteria);
		else
			throw new WrongDataException();
		}
		catch(Exception e){
			return null;
		}
		
		
		//write code here
		return list;
	}
	public static void main(String[] args) {
		//write code here
	}

}
