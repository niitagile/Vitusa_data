package com.wipro.candidate.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.util.DBUtil;




public class CandidateDAO {
	Connection con=DBUtil.getDBConn();
	public String addCandidate(CandidateBean studentBean)
	{
			String status="";
			
			try{
				CandidateDAO obj=new CandidateDAO();	
				String sql="insert into CANDIDATE_TBL values(?,?,?,?,?,?,?)";
				PreparedStatement ps=con.prepareStatement(sql);
				ps.setString(1, obj.generateCandidateId(studentBean.getName()));
				ps.setString(2,studentBean.getName());
				ps.setInt(3,studentBean.getM1());
				ps.setInt(4,studentBean.getM2());
				ps.setInt(5,studentBean.getM3());
				ps.setString(6, studentBean.getResult());
				ps.setString(7,studentBean.getGrade());
				
				int i=ps.executeUpdate();
				if(i>0) 
				{
					status= "SUCCESS";	
				}
				
				
		}catch(SQLException e){
			status="FAIL";
			e.printStackTrace();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
			//write code here
			

			return status;
	}
	public ArrayList<CandidateBean> getByResult(String criteria)
	{
		ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();
		//write code here
		ResultSet res=null;
		
		try
		{
			Connection con=DBUtil.getDBConn();
			String sql="";
				if(criteria.equals("PASS")||criteria.equals("FAIL"))	
				sql="select * from CANDIDATE_tbl where result='"+criteria+"'";
				else
				sql="select * from CANDIDATE_tbl";
							
			PreparedStatement ps=con.prepareStatement(sql);
			
			res=ps.executeQuery();
			while(res.next())
			{
					CandidateBean bean=new CandidateBean();
					bean.setId(res.getString(1));
					bean.setName(res.getString(2));
					bean.setM1(res.getInt(3));
					bean.setM2(res.getInt(4));
					bean.setM3(res.getInt(5));
					bean.setResult(res.getString(6));
					bean.setGrade(res.getString(7));
					list.add(bean);
				
			}
			
		}
		catch(Exception e){
			return null;
			//e.printStackTrace();
		}
		
		   //write code here
		
		
		return list;
	}
	public String generateCandidateId (String name)
	{
		String id="";
		//write code here
try {
			
			Connection con=DBUtil.getDBConn();
			ResultSet res;
			Statement st=con.createStatement();
			String sql="select Candid_seq.nextval from dual";
			res=st.executeQuery(sql);
			if(res.next())
			{
				id= name.substring(0,2).toUpperCase()+res.getInt(1);
			}				
				
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		
		return id;
	}
}
