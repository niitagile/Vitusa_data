package Imp_Classes;
class Student{

	@Override
/*	public String toString() {
		return "Student [getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}*/
	public String toString(){
		return "Hello EveryOne!";
	}
	
}
public class Object_Class {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String Str = new String("Welcome");
	      System.out.println("Hashcode for Str :" + Str.hashCode() );
		Student stud=new Student();
		System.out.println(stud.toString());
		
	}

}
