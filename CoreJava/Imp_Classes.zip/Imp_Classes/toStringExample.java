package Imp_Classes;
class Test{

	@Override
	/*public String toString() {
		return "Test [getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}*/
	public String toString(){
		return "Hello EveryOne!";
	}
	
}
public class toStringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Test obj=new Test();
			System.out.println(obj);
	}

}
