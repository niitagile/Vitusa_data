package Imp_Classes;
class StudentInfo implements Cloneable{  
	int rollno;  
	String name;  
	  
	StudentInfo(int rollno,String name){  
	this.rollno=rollno;  
	this.name=name;  
	}  
	  
	public Object clone()throws CloneNotSupportedException{  
	return super.clone();  
	}  
}
public class CloneExample {
	
		  
		public static void main(String args[]){  
		try{  
		StudentInfo s1=new StudentInfo(101,"amit");  
		  
		StudentInfo s2=(StudentInfo)s1.clone();  
		  
		System.out.println(s1.rollno+" "+s1.name);  
		System.out.println(s2.rollno+" "+s2.name);  
		  
		}catch(CloneNotSupportedException c){}  
		  
		}  
		}  