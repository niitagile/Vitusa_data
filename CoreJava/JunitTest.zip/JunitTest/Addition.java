package JunitTest;

public class Addition {
	public int divide(int a, int b){
		return a/b;
	}
	public int sum(int a,int b){
		System.out.println(a+b);
		return a+b;
	}
}
