package exception_Handling;

import java.util.Scanner;

public class ExceptionExample2 {

	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a value");
		int a=sc.nextInt();
		System.out.println("Enter a value");
		int b=sc.nextInt();
		try{
			int c=a/b;
			System.out.println(c);
			//throw new ArithmeticException();
		}
		catch(ArithmeticException exe){
			exe.printStackTrace();
		}
		System.out.println("End of Program");

	}

}
