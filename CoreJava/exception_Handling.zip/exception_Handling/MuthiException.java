package exception_Handling;

public class MuthiException {
		static void getInfo() throws ArithmeticException, NumberFormatException{
			//System.out.println(5/0);
			int a=Integer.parseInt("A101");
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			getInfo();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}

	}

}
