package exception_Handling;

public class trywithtryExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			try{
				int a=Integer.parseInt("A101");
				try{
					int b=Integer.parseInt("S101");
					System.out.println(5/0);
				}
				catch(ArithmeticException e){
					e.printStackTrace();
					
				}
			}
			catch(NumberFormatException e){
				e.printStackTrace();
			}
	}

}
