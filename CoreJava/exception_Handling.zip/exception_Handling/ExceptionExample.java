
import java.io.FileInputStream;

import java.io.IOException;

import java.util.Scanner;
 

 
 	public class ExceptionExample {
 		static void test() throws Error {
 			 if (true) throw new AssertionError();
 				System.out.print("test ");
 		 }

 		 public static void main(String[] args) {
 			 try { 
 				test(); 
 			}
 			catch (Exception ex) { 
 			System.out.print("exception "); 
 			}
 		 	System.out.print("end ");
 		 }


	
		 

	
}
}
