package exception_Handling;

public class ExecptionExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=5;
		int b=0;
		try{
		System.out.println(a/b);
		
		}
		catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("Hello");	
	}

}
