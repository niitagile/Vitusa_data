package exception_Handling;

class A{
	int a;
	public void getdata(){ a=67;}
	public void display(){System.out.println("a="+a);}
	public String toString(){
		return ""+a;
	}
}
public class ToStringExample {

	public static void main(String[] args) {
		A obj=new A();
		obj.getdata();
		System.out.println(obj);
		

	}

}
