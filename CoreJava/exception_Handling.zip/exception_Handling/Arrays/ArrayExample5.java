package Arrays;
public class ArrayExample5 {
    public static void main(String[] args) {
        int []arr={2,6,-22,56,78,89,9,0,55,11};
        
        int i;
        for(i=0;i<10;i++)
        {
            System.out.println(arr[i]);
        }
        
    }
}
