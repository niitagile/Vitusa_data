package Arrays;

public class ArrayExample4 {
    public static void main(String[] args) {
        int []arr=new int[10];
        arr[0]=8;
        arr[1]=-7;
        arr[2]=2;
        arr[3]=5;
        arr[4]=111;
        arr[5]=45;
        arr[6]=67;
        arr[7]=33;
        arr[8]=11;
        arr[9]=90;
        int i;
        for(i=0;i<arr.length;i++)
        {
            System.out.println(arr[i]);
        }
        
    }
}
