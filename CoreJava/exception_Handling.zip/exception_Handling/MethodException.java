package exception_Handling;

import java.util.Scanner;

public class MethodException {
public static void display(){
	System.out.println("I am display method");
}
	public static void getInfo()
			throws ArithmeticException, ArrayIndexOutOfBoundsException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter I value");
		int a=sc.nextInt();
		System.out.println("Enter II value");
		int b=sc.nextInt();
		int c=a/b;
		System.out.println("ans="+c);
		int arr[]={56};
		arr[12]=90;
		System.out.println("Hello");

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//try{
			getInfo();
		/*}
		catch(Exception e){
			e.printStackTrace();
		}*/
		display();

	}

}
