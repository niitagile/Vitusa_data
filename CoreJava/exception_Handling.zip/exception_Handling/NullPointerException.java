package exception_Handling;
class B{
	void display(){
		System.out.println("Hello");
	}
}
public class NullPointerException {
public static void main(String[] args) {
	B obj=null;
	obj.display();
}
}
