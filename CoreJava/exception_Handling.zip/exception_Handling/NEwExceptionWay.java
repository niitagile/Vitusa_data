package exception_Handling;

public class NEwExceptionWay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			int num=Integer.parseInt("A101");
			System.out.println(5/0);
		}
		catch(ArithmeticException|NumberFormatException e){
			e.printStackTrace();
		}
		
		catch(Exception e){
			e.printStackTrace();
		}

	}

}
