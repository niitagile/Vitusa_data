package exception_Handling;

public class TryExample3 {
	 public static void getInfo()throws NumberFormatException{
		 int num=Integer.parseInt("A101");
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		try{
			System.out.println("inside try block");
			getInfo();
			System.out.println(5/0);
		
		
		}
		catch(NumberFormatException e){
			e.printStackTrace();
		}
		catch(ArithmeticException e){
			e.printStackTrace();
		}
		
		
		System.out.println("Hello");
	}		

}
