package exception_Handling;
class Invariant{
	static void checkNum(int num){
		int x=num;
		if(x>0)
			System.out.println("number is +ve"+x);
	
	else if(x==0)
		System.out.println("no is 0"+x);
	else
		assert(x>0);
}
}
public class InvartaintExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Invariant.checkNum(-4);
	}

}
