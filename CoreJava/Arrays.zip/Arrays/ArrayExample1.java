
public class ArrayExample {
    public static void main(String[] args) {
        int []arr=new int[10];
        arr[0]=5;
        arr[5]=10;
        arr[9]=20;
        System.out.println("First "+arr[0]);
        System.out.println("Second "+arr[5]);
        System.out.println("Third "+arr[9]);
    }
}
