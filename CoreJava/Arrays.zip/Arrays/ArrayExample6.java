package Arrays;
public class ArrayExample6 {
    public static void main(String[] args) {
        String []names={"Amit","Sumit","Rajiv"};
        System.out.println(names[1]);
    }
}
