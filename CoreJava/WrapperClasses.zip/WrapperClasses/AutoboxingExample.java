package WrapperClasses;


public class AutoboxingExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*char ch='A';
		int ch1=ch;
		System.out.println(ch1);*/
		String s="123";
		int num=Integer.parseInt(s);
		System.out.println(num);
		float num1=Float.parseFloat(s);
		
		
	}

}
