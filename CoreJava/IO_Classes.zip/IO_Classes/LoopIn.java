package IO_Classes;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class LoopIn {
	public static void main(String[] args) {
		System.out.println("Enter the text you want to store in a file: ");
		Scanner s = new Scanner(System.in);
		String data="";
		do{
			try {
				data = s.nextLine();
				FileWriter fw = new FileWriter("/home/harsha/java/FHD/loop.txt", true);
				PrintWriter pw = new PrintWriter(fw);
				pw.println(data);
				pw.println();
				pw.close();
				fw.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}while(!data.equals("end"));
	}
}
