package fileRead;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.Scanner;

public class Readfle {
	public static void main(String[] args) {
		System.out.println("Enter File name from the Dir \n /home/siva/java/FHD to read");
		Scanner s=new Scanner(System.in);
		String fname=s.next();
		try {
			FileReader pw=new FileReader("/home/harsha/java/FHD/"+fname+".txt");
			BufferedReader br=new BufferedReader(pw);
			String str="";
			while((str=br.readLine())!=null)
			{
				System.out.println(str);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("File not found");
			System.out.println();
		}

	}
}
