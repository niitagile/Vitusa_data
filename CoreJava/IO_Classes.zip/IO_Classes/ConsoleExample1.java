package IO_Classes;

import java.io.Console;
class ConsoleExample1{  
public static void main(String args[])throws Exception{  
Console c=System.console();
System.out.println(c);
System.out.println("Enter your name: ");  
String n=c.readLine();
System.out.println("Enter your password");
String pw=new String(c.readPassword());
System.out.println("Welcome "+" "+pw);  
}  
}  