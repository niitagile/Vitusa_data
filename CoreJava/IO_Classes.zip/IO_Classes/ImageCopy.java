package IO_Classes;
import java.io.*;
public class ImageCopy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
         
        try
        {
            FileReader fin=new FileReader("Output.jpeg");
            FileWriter fout=new FileWriter("Output2.jpeg");
            int b;
            while((b=fin.read())!=-1){
            	fout.write(b);
            }
            fin.close();
            fout.close();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
         
        System.out.println("done");
    }
	}


