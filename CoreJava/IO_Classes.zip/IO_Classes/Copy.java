package IO_Classes;

import java.io.*;

public class Copy {
	public static void main(String[] args) {
		try {
			FileReader pw=new FileReader("/home/siva/java/FHD/user.txt");
			BufferedReader br=new BufferedReader(pw);
			String str="";
			while((str=br.readLine())!=null)
			{
			FileWriter fw=new FileWriter("/home/harsha/java/FHD/user1.txt",true);
			PrintWriter p=new PrintWriter(fw);
			p.println(str);
			p.close();
			}
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("File not found");
		}
		
	}
}
