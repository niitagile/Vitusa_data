package IO_Classes;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class UsrEnterFN {
	public static void main(String[] args) {
		System.out.println("Enter file Name: ");
		Scanner s=new Scanner(System.in);
		String fname=s.nextLine();
		System.out.println("Enter a line to Enter into the file: ");
		String data=s.nextLine();
		FileWriter fw;
		try {
			fw = new FileWriter("/home/harsha/java/FHD/"+fname+".txt");
			PrintWriter pw=new PrintWriter(fw);
			pw.println(data);
			pw.println();
			pw.close();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
