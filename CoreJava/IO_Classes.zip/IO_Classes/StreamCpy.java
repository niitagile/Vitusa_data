package cpyIoStream;

import java.io.*;

public class StreamCpy {
	public static void main(String[] args) {
		try {
			InputStream pw=new FileInputStream("/home/siva/java/FHD/user.txt");
			
			String str="";
			//while((str=br.readLine())!=null)
			{
			FileWriter fw=new FileWriter("/home/harsha/java/FHD/user1.txt");
			PrintWriter p=new PrintWriter(fw);
			p.println(str);
			p.close();
			}
			//br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("File not found");
		}
		
	}

}
