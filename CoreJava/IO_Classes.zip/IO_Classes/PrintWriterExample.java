package IO_Classes;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;


public class PrintWriterExample {
    public static void main(String[] args) {
        PrintWriter pw=null;
        try {
            pw=new PrintWriter("jk.txt");
            pw.print("Maja aaya");
        } catch (IOException ex) {
            System.out.println("Problem");
        }finally{
            pw.close();
        }
    }
}
