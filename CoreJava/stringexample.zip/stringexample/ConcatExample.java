package stringexample;

public class ConcatExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(5+7);//12
		System.out.println("5"+7);//57
		System.out.println("sum="+5+7);//sum=57
		System.out.println("sum="+(5+7));//sum=12
	}

}
