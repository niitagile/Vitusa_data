package stringexample;

public class indexofexample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Hello Class we !are learning string";
		int pos=s.indexOf("we");
		System.out.println(pos);
		
	}

}
