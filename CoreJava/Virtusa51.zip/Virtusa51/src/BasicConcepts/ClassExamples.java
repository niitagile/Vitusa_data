package BasicConcepts;

import java.util.Scanner;
//use of this keyword
/*class Class1{
	private int num;
	void info(){
		Scanner sc=new Scanner(System.in);
		System.out.println("enter value");
			num=sc.nextInt();
		}
	void display(){
		int num=70;
		System.out.println(num);
		System.out.println(this.num);
	}
}
public class ClassExamples {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Class1 obj=new Class1();
		obj.info();
		obj.display();
		
	}

}*/
//this()- to call constructorinside construtor
 class Class1{
	 int rollno;
	 String name;
	 Class1(int rollno,String name){
		 this(name);// constructor calling
		 this.rollno=rollno;
		System.out.println("First Constructor");
	 }
	 Class1(String name){
		 this.name=name;
		 System.out.println("Second Construtor");
		 
	 }
 }
 public class ClassExamples {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Class1 obj=new Class1(12, "Kiran");
			
			System.out.println("rollno="+obj.rollno);
			System.out.println("name="+obj.name);
			
		}

	}


//getter and setter are used to get /set values of data members
/*class Class1{
	private int rollno;
	private String name;
	
	public int getRollno(){
		return rollno;
	}
	public void setRollno(int rollno){
		this.rollno=rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}




public class ClassExamples {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Class1 obj=new Class1();
		obj.setRollno(34);
		obj.setName("Leena");
		System.out.println("rollno="+obj.getRollno());
		System.out.println("name="+obj.getName());
		
	}

}*/
