package BasicConcepts;

import java.util.Scanner;

class Person{
	String pname;
	void getInfo(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name");
		pname=sc.nextLine();
	}
	void display(){
		System.out.println("name="+pname);
	}
}
public class ArrayOfObjectExample {
	public static void main(String[] args) {
		Person PersonArray[]=new Person[3];
		for(int i=0;i<PersonArray.length;i++){
			PersonArray[i]=new Person();
			PersonArray[i].getInfo();
			
			
		}
		for(Person obj : PersonArray){
			obj.display();
			
		}
		/*
		 * Person p=new Person();-- instance object
		 * p.display();
		 * p.getInfo();
			new Person().display();//anonymous object
			Person stud=p;//address of any other object. works just like pointers. Reference object
		*/
	}
}
