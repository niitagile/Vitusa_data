package BasicConcepts;

import java.util.Scanner;

class Student{
	int rollno;
	String name;
	//default constructor-- either create by compiler or developer
	Student(){
		rollno=0;
		name=null;
	}
	/*public Student(int r, String s) {
		// TODO Auto-generated constructor stub
		rollno=r;
		name=s;
		
	}*/
	
	void display(){
		
		System.out.println("rollno="+rollno);
		System.out.println("name="+name);
	}
	public Student(int rollno, String name) {
		super();
		this.rollno = rollno;
		this.name = name;
	}
}
public class ClssExamples {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student student1=new Student();
		student1.display();
		Scanner sc=new Scanner(System.in);
		System.out.println("Information about Object2");
		System.out.println("Enter rollno");
		int r=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter name");
		String s=sc.nextLine();
		Student student2=new Student(r,s);
		student2.display();

	}

}
