package BasicConcepts;

import java.util.Scanner;

public class FirstClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Ente a word");
		String word= sc.next();
		sc.nextLine();
		System.out.println("Eneter a sentence");
		String sen=sc.nextLine();
		System.out.println("Enter character");
		char ch=sc.next().charAt(0);
		
		System.out.println("Enter a value");
		int num=sc.nextInt();
		System.out.println("Enter marks");
		double marks=sc.nextDouble();
		
		boolean a=true;
		if(a)
			System.out.println("Hello");
		else
			System.out.println("Welcome");	

	}
		
		
		
			
	}

}
