package ControlStatements;


public class Series {

	public static void main(String[] args) {
		
		System.out.print("[ ");
		for(int i=1; i<=5; i++)
		{
			System.out.print(((i*i)+1)+" ");
		}
		System.out.print("]");
	}

}
