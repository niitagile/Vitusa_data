package ControlStatements;
class If_example1
{
	
	public static void main(String []args)
	{
		/*int x=1;
		int y=20;
		if(x>5 && y++ > 20)
		{
			System.out.println("Hello");
		}
		else
		{
			System.out.println("Bye");
		}
		System.out.println(y);*/
		
		boolean x=true;
		if(x)
		System.out.print("Hello");
		else
		System.out.print("Bye");



	}
}

