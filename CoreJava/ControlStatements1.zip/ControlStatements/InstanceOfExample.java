package ControlStatements;
//Object, String
public class InstanceOfExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			String s=new String("Hello");
			System.out.println(s instanceof String);
			System.out.println(s instanceof Object);
			System.out.println(s instanceof student);
	}

}
