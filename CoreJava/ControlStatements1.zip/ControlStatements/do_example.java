package ControlStatements;

public class do_example {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 10;

	      do{
	         System.out.print("value of x : " + x );
	         x++;
	         System.out.println();
	      }while( x < 20 );

	}

}
