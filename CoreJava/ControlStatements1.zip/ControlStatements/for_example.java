package ControlStatements;

public class for_example {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=5;
		 for(;; ) {
	         System.out.print("value of x : " + x );
	         if(x==8)
	        	 break;
	         System.out.println();
	         x++;
	      }

	}

}
