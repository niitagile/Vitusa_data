package ControlStatements;


public class SumofsquareNatural {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		System.out.println("start");
		for(int i=1; i<=10; i++)
		{
			sum=sum+(i*i);
		}
		System.out.println(sum);
	}

}
