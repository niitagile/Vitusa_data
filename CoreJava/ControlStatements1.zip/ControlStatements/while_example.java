package ControlStatements;

public class while_example {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int x = 10;

	      while( x < 20 ) {
	         System.out.print("value of x : " + x );
	         x++;
	         System.out.println();
	      }

	}

}
