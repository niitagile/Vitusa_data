package LambdaExamples;
interface Shape{
	 void draw();
}
/*class Rectangle implements Shape{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("area of rectangle is L*B");
	}
	
}*/
public class LambdaExpression {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*	Shape s=new Rectangle();
			s.draw();*/
			
			//Lambda Expression
			Shape s1=()-> System.out.println("area of rectangle is L*B");
			s1.draw();
			
	}

}
