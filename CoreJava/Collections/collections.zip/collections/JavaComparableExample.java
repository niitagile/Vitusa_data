package collections;

class Employee1 implements Comparable
{
	private int age;
	public void setAge(int age)
	{
	this.age=age;
	}
	public int getAge()
	{
	return this.age;
	}
	public int compareTo(Object otherEmployee)// method to be overridden from Comparable Class
	  {	//If passed object is of type other than Employee, throw ClassCastException.	
	//	if( ! ( otherEmployee instanceof Employee ) )
	//		{ throw new ClassCastException("Invalid object");}
		int age = ( (Employee1) otherEmployee ).getAge();
		if(  this.getAge() > age )
			return 1;
		else if ( this.getAge() < age )
			return -1;
		else
		return 0;
	 }
}
public class JavaComparableExample
{
	  public static void main(String args[])	
		 {
			Employee1 one = new Employee1();
			one.setAge(40);
			Employee1 two = new Employee1();
			two.setAge(130);

			if( one.compareTo(two) > 0 ) 
				{System.out.println("Employee one is elder than employee two !");
				} 
			else if( one.compareTo(two) < 0 ) 
				{System.out.println("Employee one is younger than employee two !");
				} 
			else if( one.compareTo(two) == 0 ) 
				{System.out.println("Both employees are same !");
				} 
		}
}


/*
	Signature of compareTo method is.
	public int compareTo(Object object).
	compareTo method should return 0 if both objects are equal,
	1 if first greater than other and -1 if first less than the other object of the same class.
	*/