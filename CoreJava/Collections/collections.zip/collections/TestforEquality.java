package collections;

public class TestforEquality {

	public static void main(String[] args) {
		StudentInstance s= new StudentInstance();
		Movie first = new Movie("Pk", "Aamir", 2.5f);
		Movie second1  = new Movie("Pk1", "Aamir", 2.5f);
		
		//first is the current object here
//second1 is the parameterized object which is in Object for right now

//equals signature(from Object class) ==> public boolean equals(Object o)

		if(first.equals(second1)){
			System.out.println("Movies Objects are equal");
		}
		else{
			System.out.println("They aren't equal");
		}
		
	}

}
