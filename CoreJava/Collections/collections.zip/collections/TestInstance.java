package collections;

public class TestInstance {

	public static void main(String[] args) {
		StudentInstance si = new StudentInstance();
		EmployeeInstance ei = new EmployeeInstance();
		
		
		if(!(si instanceof StudentInstance)){
			System.out.println("employee object");
		}
		else{
			System.out.println("Si object");
		}
		
		System.out.println("object check ");
		
		B obj = new B();
		if(obj instanceof A){
			System.out.println("A's type object");
		}
		

	}

}
