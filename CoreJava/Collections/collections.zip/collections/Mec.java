package collections;

public class Mec implements Engineering{

	Mec(){
		System.out.println("Mec COnst");
	}
	
	@Override
	public void display() {
		System.out.println("Object details");
		System.out.println("======================");
		System.out.println("College name "+collegeName);
		System.out.println("Stream is Mechanical engg.");
		
	}
	
	public String toString(){
		return ("Attending Mec Class from "+collegeName);
	}
	
}
