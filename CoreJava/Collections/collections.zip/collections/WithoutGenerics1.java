package collections;

import hasarelation.Subject;
import discussed.Student;

import java.util.ArrayList;
import java.util.Iterator;

public class WithoutGenerics1 {
	
	public static void main(String[] args) {
		
		ArrayList<Subject> alobj = new ArrayList<Subject>();
		//4 subject objects
		alobj.add(new Subject("English", 90, 10));
		alobj.add(new Subject("Hindi", 70, 10));
		alobj.add(new Subject("CS", 50, 10));
		alobj.add(new Subject("Literature", 20, 10));
		//2 student objects
		
		/*alobj.add(new Student());    compilation for Student() object
		alobj.add(new Student());
		alobj.add(1);*/
				
				
		System.out.println("==============printing al contents=========");
		int val=0;
		for(Iterator i = alobj.iterator(); i.hasNext(); ){
			Subject obj = (Subject) i.next();
			System.out.println(obj);
		}		
	}
}
