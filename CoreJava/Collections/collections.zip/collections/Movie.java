package collections;

public class Movie {
	String name;
	String actor;
	float duration;
	
	
	public Movie(String name, String actor, float duration){
		this.name = name;
		this.actor = actor;
		this.duration = duration;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getActor() {
		return actor;
	}
	public void setActor(String actor) {
		this.actor = actor;
	}
	public float getDuration() {
		return duration;
	}
	public void setDuration(float duration) {
		this.duration = duration;
	}
	@Override
	public String toString() {
		return ("The movie "+name+" has "
	+actor+" as the actor."+duration+" is the hourly duration");
	}
	
	public boolean equals(Object o){
		System.out.println("Equals in action");
		//1. first ensure that the object passed in the 
		//parameter is Movie class object
		
		if(!(o instanceof Movie)){
			//if o is not Movie class Object it throws exception
			throw new ClassCastException("Invalid comparison object");
		}
		
		//otherwise the program continues fine
		
		//2. first convert the object type to movie type (explicit typecasting)
		//so that we can call the methods / variables of Movie class
				
		//Movie type =(Movie)Object type
		Movie paramobject = (Movie)o;
		
		//3. compare the values 
		if(
			(this.getName().equals((paramobject.getName())))
				&& 
			(this.getActor().equals((paramobject.getActor())))
						&&
			(this.getDuration()==((paramobject.getDuration())))
		){
			
			return true;
		}
		else{
			return false;
		}
	}
}
