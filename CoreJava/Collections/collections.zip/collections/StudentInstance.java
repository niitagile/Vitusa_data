package collections;

public class StudentInstance {
	public StudentInstance() {
		System.out.println("StudentInstance");
	}
}
