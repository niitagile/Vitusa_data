package collections;
import java.util.*;

class Employee2
{
	private int age;
	private String name;
	public void setAge(int age)
	{        
		this.age=age;
	}
	public int getAge(){          
		return this.age;
	}
	public void setName(String name)
	{         
		this.name=name;
	}
	public String getName()
	{
		return this.name;
	}     
}

class AgeComparator implements Comparator{
	public int compare(Object emp1, Object emp2){
		Employee2 e1 = (Employee2)emp1;
		Employee2 e2 = (Employee2)emp2;
		int emp1Age = e1.getAge();
		int emp2Age = e2.getAge();
		if( emp1Age > emp2Age )
			return 1;
		else if( emp1Age < emp2Age )
			return -1;
		else
			return 0;
	}
}

class NameComparator implements Comparator{
	public int compare(Object emp1, Object emp2){
		String emp1Name = ( (Employee2) emp1 ).getName();
		String emp2Name = ( (Employee2) emp2 ).getName();
		return emp1Name.compareTo(emp2Name);
	}
}

public class JavaComparatorExample{
	public static void main(String args[]){

		Employee2 employee[] = new Employee2[2];
		employee[0] = new Employee2();
		employee[0].setAge(40);
		employee[0].setName("Joe");
		
		employee[1] = new Employee2();
		employee[1].setAge(20);
		employee[1].setName("Mark");
		
		System.out.println("Order of employee before sorting is");
		//print array as is.
		for(int i=0; i < employee.length; i++){
			System.out.println( "Employee " + (i+1) + " name :: " + employee[i].getName() + ", Age :: " + employee[i].getAge());
		}

		AgeComparator ac= new AgeComparator();
		Arrays.sort(employee,ac);

		System.out.println("\n\nOrder of employee after sorting by employee age is");
		for(int i=0; i < employee.length; i++){
			System.out.println( "Employee " + (i+1) + " name :: " + employee[i].getName() + ", Age :: " + employee[i].getAge());
		}

		Arrays.sort(employee, new NameComparator());
		System.out.println("\n\nOrder of employee after sorting by employee name is");      
		for(int i=0; i < employee.length; i++){
			System.out.println( "Employee " + (i+1) + " name :: " + employee[i].getName() + ", Age :: " + employee[i].getAge());
		}
	}
}
