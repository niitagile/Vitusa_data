package collections;

public class Applicant {
	String name, id, language;
	
	public Applicant(){
		name="Shyam";
		id="101";
		language ="java";
	}
	public Applicant(String name, String id, String language) {
		super();
		this.name = name;
		this.id = id;
		this.language = language;
	}

	@Override
	public String toString() {
		return name+" has id -"+id+" & knows "+language+" language";
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	
	
}
