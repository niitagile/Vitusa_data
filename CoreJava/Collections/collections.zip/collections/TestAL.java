package collections;

import java.util.ArrayList;
import java.util.Iterator;

public class TestAL {
	public void printValues(ArrayList al){
		//reading the arraylist received by teh parameter
		
		for(int i=0; i<al.size(); i++){
			Engineering obj = (Engineering) al.get(i);
			obj.display();
		}		
		
		for(Iterator a =al.iterator(); a.hasNext() ;){
			 System.out.println(a.next());
		}
	}
	
	public static void main(String[] args) {
		ArrayList al = new ArrayList();
		TestAL obj = new TestAL();
		
		
		Engineering refVar;	//created ref variable of the inter type
		refVar = new CS();	//making ref point to sub class
		
		al.add(refVar);		//adding object
		
		refVar = new Mec(); //making ref point to another sub class obj
		al.add(refVar);

		refVar = new CS();//making ref point to another sub class obj
		al.add(refVar);
		
		refVar = new Mec();//making ref point to another sub class obj
		al.add(refVar);
		
		obj.printValues(al);   // passing al to the print to process it
	
	}

}
