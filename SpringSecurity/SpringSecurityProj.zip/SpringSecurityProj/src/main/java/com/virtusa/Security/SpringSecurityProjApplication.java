package com.virtusa.Security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityProjApplication.class, args);
	}

}
