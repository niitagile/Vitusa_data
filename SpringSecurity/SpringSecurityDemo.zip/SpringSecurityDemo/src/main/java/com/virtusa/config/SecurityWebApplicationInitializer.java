package com.virtusa.config;

import org.springframework.security.web.context.*;  

public class SecurityWebApplicationInitializer  
    extends AbstractSecurityWebApplicationInitializer {  
  
}  