package pkg;

public class Employee {
	private String ename,designation;

	public String getEname() {
		return ename;
	}

	public void setEname(String name) {
		this.ename = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
	

}
