package com.Dao;
import java.util.*;
import java.sql.*;

import com.beans.Login;

public class LoginDao {

	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr1");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	
	public static boolean validate(Login obj){
		
		boolean ans = false;
		try{
		
			Connection con=LoginDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from Employe where id=? and password=?");
			ps.setString(1,obj.getUsername());
			ps.setString(2, obj.getPword());
			ResultSet rs=ps.executeQuery();
			ans= rs.next();
			
			
			
		}catch(Exception ex){ex.printStackTrace();}
		return ans;
		
	}
	
}
