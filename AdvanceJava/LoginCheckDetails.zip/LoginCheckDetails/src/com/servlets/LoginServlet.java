package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.LoginDao;
import com.beans.Login;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String user=request.getParameter("txtUser");
		String password=request.getParameter("txtPassword");
		Login obj=new Login();
		obj.setUsername(user);
		obj.setPword(password);
		PrintWriter out=response.getWriter();
		if(LoginDao.validate(obj)){
			out.println("Welcome "+user);
		}
		else
			out.println("Invalid User name and Password");
		
		
		
	}

}
