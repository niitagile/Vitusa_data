

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 * RequestDispatcher- It is an interface to dispatch the another reqest or resource-- (html/jsp/servlet)
 *forward(), include()
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd=null;
		String uname= request.getParameter("txtUser");
		String password=request.getParameter("txtPword");
		PrintWriter out =response.getWriter();
		if(uname.equalsIgnoreCase("Java") && password.equals("Java@123") )
		{	HttpSession session=request.getSession(true);
			session.setAttribute("username", uname);
			rd=request.getRequestDispatcher("WelcomeServlet");
			rd.forward(request, response);
		}	
		else
		{
			
			out.println("Sorry UserName or Password is Wrong");
			rd=request.getRequestDispatcher("Login.html");
			rd.include(request, response);
			
		}
		
	}

}
